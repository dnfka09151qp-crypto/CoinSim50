# 코인 시뮬레이션 50 (Android)

- 가상 초기자금: 10,000,000 KRW
- 실제 업비트 KRW 마켓 시세 사용 (인증 없는 공개 Quotation API)
- 24시간 거래대금 기준 상위 50종 자동 표시
- 가상 매수/매도, 보유수량, 총자산, 수익률
- 실제 주문/출금/입금/API Key 사용 없음

## Android Studio 없이 APK 만들기

1. 이 ZIP을 풀고 `CoinSim50` 폴더 안의 파일들을 GitHub 저장소 최상위에 업로드합니다.
2. GitHub 저장소의 **Actions** 탭을 엽니다.
3. `Build Android APK` 워크플로를 선택하고 **Run workflow**를 누릅니다. `main` 또는 `master` 브랜치에 push해도 자동 실행됩니다.
4. 빌드가 끝나면 실행된 workflow의 요약 화면 아래 **Artifacts**에서 `CoinSim50-debug-apk`를 다운로드합니다.
5. 내려받은 ZIP을 풀면 `app-debug.apk`가 있습니다. Android 휴대폰으로 옮겨 설치하세요. 휴대폰 설정에서 해당 파일 앱의 '알 수 없는 앱 설치'를 허용해야 할 수 있습니다.

## 버전 Release로 APK 받기

`v1.0.0`처럼 `v`로 시작하는 태그를 push하면 workflow가 APK를 빌드하고 GitHub Release에 APK를 첨부합니다.

## 빌드 설정

- compileSdk 35 / minSdk 24 / targetSdk 35
- Android Gradle Plugin 8.7.3
- JDK 17 / Gradle 8.9

GitHub Actions 설정은 `.github/workflows/build-apk.yml`에 있습니다. GitHub-hosted runner에서 Android SDK를 설치하고 빌드하므로 로컬 Android Studio는 필요하지 않습니다.

주의: 업비트 API 정책과 이용약관을 준수하세요. 시세 API는 공개 Quotation API이며, 실제 자산 거래 기능은 포함하지 않습니다. 이 프로젝트는 교육/모의투자용이며 투자 조언이 아닙니다.
